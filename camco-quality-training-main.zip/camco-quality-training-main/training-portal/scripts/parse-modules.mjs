#!/usr/bin/env node
import { readdir, readFile, writeFile, mkdir } from 'fs/promises';
import { join } from 'path';

const MODULES_DIR = '/home/user/Quality_Manager_Training';
const OUTPUT_DIR = join(import.meta.dirname, '..', 'src', 'data');

async function getModuleDirs() {
  const entries = await readdir(MODULES_DIR);
  return entries
    .filter(e => /^Module_\d+$/.test(e))
    .sort((a, b) => parseInt(a.split('_')[1]) - parseInt(b.split('_')[1]));
}

function extractTitle(lessonText) {
  const match = lessonText.match(/^MODULE\s+\d+:\s+(.+)$/m);
  return match ? match[1].trim() : 'Unknown Module';
}

function extractSections(lessonText) {
  const sections = [];
  const lines = lessonText.split('\n');
  let currentTitle = null;
  let currentContent = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.match(/^={10,}$/) && i + 1 < lines.length) {
      const nextLine = lines[i + 1];
      if (nextLine && nextLine.match(/^[A-Z][A-Z0-9 :&/\-—(),.']+$/) && i + 2 < lines.length && lines[i + 2]?.match(/^={10,}$/)) {
        if (currentTitle) {
          sections.push({ title: currentTitle, content: currentContent.join('\n').trim() });
        }
        currentTitle = nextLine.trim();
        currentContent = [];
        i += 2;
        continue;
      }
    }
    if (currentTitle) {
      currentContent.push(line);
    }
  }
  if (currentTitle) {
    sections.push({ title: currentTitle, content: currentContent.join('\n').trim() });
  }
  return sections;
}

function parseQuizQuestions(quizText) {
  const questions = [];
  const lines = quizText.split('\n');
  let sectionType = null;

  let i = 0;
  while (i < lines.length) {
    const line = lines[i];

    // Skip dividers
    if (line.match(/^[=-]{5,}$/)) { i++; continue; }

    // Detect section type headers
    if (line.match(/^\s*MULTIPLE CHOICE/i) && !line.match(/^\s*\d+\./)) {
      sectionType = 'mc'; i++; continue;
    }
    if (line.match(/^\s*TRUE\s*\/?\s*FALSE/i) && !line.match(/^\s*\d+\./)) {
      sectionType = 'tf'; i++; continue;
    }
    if (line.match(/^\s*SHORT ANSWER/i) && !line.match(/^\s*\d+\./)) {
      sectionType = 'sa'; i++; continue;
    }
    if (line.match(/^\s*SCENARIO/i) && !line.match(/^\s*\d+\./)) {
      sectionType = 'scenario'; i++; continue;
    }

    // Format 4: "QUESTION N (Type)"
    const qHeaderMatch = line.match(/^QUESTION\s+(\d+)\s+\((Multiple Choice|True\/False|Short Answer|Scenario(?:[- ]Based)?)\)/i);
    // Format 1/2: "1. (MC) ..." or "1. (Multiple Choice) ..."
    const typedMatch = !qHeaderMatch && line.match(/^\s*(\d+)\.\s+\((MC|Multiple Choice|T\/F|True\/False|Short Answer|Scenario(?:-Based)?)\)\s+(.*)/);
    // Format 3: "1. Question text..."
    const plainMatch = !typedMatch && !qHeaderMatch && line.match(/^\s*(\d+)\.\s+(?!\()(\S.*)/);

    if (!typedMatch && !plainMatch && !qHeaderMatch) { i++; continue; }

    let num, type, questionText;

    if (qHeaderMatch) {
      num = parseInt(qHeaderMatch[1]);
      const rawType = qHeaderMatch[2];
      questionText = '';
      if (rawType.match(/multiple choice/i)) type = 'mc';
      else if (rawType.match(/true.false/i)) type = 'tf';
      else if (rawType.match(/short answer/i)) type = 'sa';
      else type = 'scenario';
    } else if (typedMatch) {
      num = parseInt(typedMatch[1]);
      const rawType = typedMatch[2];
      questionText = typedMatch[3].trim();
      if (rawType === 'MC' || rawType === 'Multiple Choice') type = 'mc';
      else if (rawType === 'T/F' || rawType === 'True/False') type = 'tf';
      else if (rawType === 'Short Answer') type = 'sa';
      else type = 'scenario';
    } else {
      num = parseInt(plainMatch[1]);
      questionText = plainMatch[2].trim();
      type = sectionType || 'unknown';
    }

    // Collect body lines until next question or section
    i++;
    const bodyLines = [];
    while (i < lines.length) {
      const nextLine = lines[i];
      // Next question (Format 4)?
      if (nextLine.match(/^QUESTION\s+\d+\s+\(/i)) break;
      // Next question (Format 1/2/3)?
      const nextQ = nextLine.match(/^\s*(\d+)\.\s+/);
      if (nextQ && parseInt(nextQ[1]) > num) break;
      // Section header?
      if (nextLine.match(/^\s*(?:MULTIPLE CHOICE|SHORT ANSWER|SCENARIO)/i) && !nextLine.match(/^\s*\d+\./)) break;
      if (nextLine.match(/^\s*TRUE\s*\/?\s*FALSE/i) && !nextLine.match(/^\s*\d+\./)) break;
      // End marker?
      if (nextLine.match(/^={10,}$/) && i + 1 < lines.length && lines[i+1]?.match(/^\s*(?:MULTIPLE|TRUE|SHORT|SCENARIO|END|QUESTION)/i)) break;
      bodyLines.push(nextLine);
      i++;
    }

    // Clean T/F from question text
    questionText = questionText.replace(/\s+T\s+F\s*$/, '').trim();

    if (type === 'mc') {
      const options = [];
      let currentOpt = null;
      let currentOptText = '';
      for (const bl of bodyLines) {
        // Match options: indented "   A. text" or un-indented "A. text"
        const optMatch = bl.match(/^\s+([A-D])[\.\s]+--\s+(.*)/) || bl.match(/^\s+([A-D])\.\s+(.*)/) || bl.match(/^([A-D])\.\s+(.*)/);
        if (optMatch) {
          if (currentOpt) options.push({ letter: currentOpt, text: currentOptText.trim() });
          currentOpt = optMatch[1];
          currentOptText = optMatch[2];
        } else if (currentOpt && bl.trim() && !bl.match(/^[-=]{5,}/) && !bl.match(/^\s*$/) && !bl.match(/^[A-D]\./)) {
          currentOptText += ' ' + bl.trim();
        } else if (!currentOpt && bl.trim() && !bl.match(/^[-=]{5,}/) && !bl.match(/^\s*$/) && !bl.match(/^\s+_/)) {
          questionText += ' ' + bl.trim();
        }
      }
      if (currentOpt) options.push({ letter: currentOpt, text: currentOptText.trim() });

      if (options.length >= 2) {
        questions.push({ number: num, type: 'mc', question: questionText, options });
      }
    } else if (type === 'tf') {
      for (const bl of bodyLines) {
        if (bl.trim() && !bl.match(/^\s*T(RUE)?\s+\/?\s*F(ALSE)?/i) && !bl.match(/^[-=]{5,}/) && !bl.match(/^\s*$/)) {
          questionText += ' ' + bl.trim();
        }
      }
      questionText = questionText.replace(/\s+T(RUE)?\s+\/?\s*F(ALSE)?\s*$/i, '').trim();
      questions.push({
        number: num, type: 'tf', question: questionText,
        options: [{ letter: 'T', text: 'True' }, { letter: 'F', text: 'False' }]
      });
    }
  }
  return questions;
}

function parseAnswerKey(answerText) {
  const answers = {};
  const quizSection = answerText.split(/\n.*TEST ANSWER KEY/i)[0];

  // Format: "1. ANSWER: B"
  let m;
  const f1 = /^(\d+)\.\s+ANSWER:\s+([A-DFT])/gm;
  while ((m = f1.exec(quizSection)) !== null) {
    answers[parseInt(m[1])] = m[2];
  }

  // Format: "1. B -- explanation" or "1.  B -- explanation"
  const f2 = /^(\d+)\.\s+([A-DFT])\s+--/gm;
  while ((m = f2.exec(quizSection)) !== null) {
    if (!answers[parseInt(m[1])]) {
      answers[parseInt(m[1])] = m[2];
    }
  }

  // Format: "1.  TRUE" or "1.  FALSE"
  const f3 = /^(\d+)\.\s+(TRUE|FALSE)\b/gmi;
  while ((m = f3.exec(quizSection)) !== null) {
    if (!answers[parseInt(m[1])]) {
      answers[parseInt(m[1])] = m[2].toUpperCase() === 'TRUE' ? 'T' : 'F';
    }
  }

  // Format 4: "QUESTION N: LETTER" or "QUESTION N: T (True)" or "QUESTION N: F (False)"
  const f4 = /^QUESTION\s+(\d+):\s+([A-DFT])\b/gmi;
  while ((m = f4.exec(quizSection)) !== null) {
    if (!answers[parseInt(m[1])]) {
      answers[parseInt(m[1])] = m[2].toUpperCase();
    }
  }

  return answers;
}

async function main() {
  await mkdir(OUTPUT_DIR, { recursive: true });
  const moduleDirs = await getModuleDirs();
  const modules = [];

  for (const dir of moduleDirs) {
    const num = parseInt(dir.split('_')[1]);
    const modulePath = join(MODULES_DIR, dir);
    const files = await readdir(modulePath);

    const lessonFile = files.find(f => f.includes('Lesson_Pack'));
    const quizFile = files.find(f => f.includes('Quiz'));
    const answerFile = files.find(f => f.includes('Answer_Key'));

    let title = `Module ${num}`;
    let sections = [];
    let quizQuestions = [];
    let answers = {};

    if (lessonFile) {
      const text = await readFile(join(modulePath, lessonFile), 'utf-8');
      title = extractTitle(text);
      sections = extractSections(text);
    }
    if (quizFile) {
      const text = await readFile(join(modulePath, quizFile), 'utf-8');
      quizQuestions = parseQuizQuestions(text);
    }
    if (answerFile) {
      const text = await readFile(join(modulePath, answerFile), 'utf-8');
      answers = parseAnswerKey(text);
    }

    for (const q of quizQuestions) {
      if (answers[q.number]) q.correctAnswer = answers[q.number];
    }

    modules.push({
      id: num,
      title,
      sections,
      quiz: quizQuestions,
      totalQuizQuestions: quizQuestions.length,
      passingScore: Math.ceil(quizQuestions.length * 0.8),
    });

    console.log(`Module ${String(num).padStart(2)}: ${String(quizQuestions.length).padStart(2)} Qs, ${sections.length} sects - "${title}"`);
  }

  await writeFile(join(OUTPUT_DIR, 'modules.json'), JSON.stringify(modules, null, 2));
  console.log(`\nWrote ${modules.length} modules to modules.json`);
}

main().catch(console.error);
