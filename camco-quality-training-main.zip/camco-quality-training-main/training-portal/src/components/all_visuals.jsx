// ============================================================
// CAMCO QUALITY MANAGER TRAINING — ALL MODULE VISUALS
// ============================================================
// Paste this entire file into Claude Code with the instruction:
// "Add all these visual components to the training portal.
//  Each component maps to its module number. Embed each one
//  inside the corresponding module lesson page after the main
//  instructional text. All components are self-contained."
// ============================================================

import { useState, useCallback, useRef } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, ReferenceLine,
  Tooltip, ResponsiveContainer, BarChart, Bar, Cell,
  RadarChart, Radar, PolarGrid, PolarAngleAxis, ScatterChart,
  Scatter, ZAxis
} from "recharts";

// ─────────────────────────────────────────────
// SHARED STYLES
// ─────────────────────────────────────────────
const S = {
  card: { background:"#1e293b", borderRadius:12, padding:20, border:"1px solid #334155", marginBottom:16 },
  badge: (color) => ({ background:color+"20", border:`1px solid ${color}40`, borderRadius:6, padding:"3px 10px", fontSize:11, fontWeight:700, letterSpacing:2, color }),
  h1: { margin:0, fontSize:20, fontWeight:700, color:"#f8fafc", letterSpacing:-0.5 },
  label: { fontSize:11, color:"#64748b", letterSpacing:1, textTransform:"uppercase", marginBottom:8 },
  pill: (color, bg) => ({ background:bg||color+"15", border:`1px solid ${color}40`, borderRadius:20, padding:"4px 12px", fontSize:11, fontWeight:700, color }),
};
const DARK = "#0f172a";
const wrap = (content) => (
  <div style={{ fontFamily:"'DM Sans','Segoe UI',sans-serif", background:"linear-gradient(135deg,#0a0f1e,#0f172a)", minHeight:"100vh", padding:24, color:"#f1f5f9" }}>
    {content}
  </div>
);


// ─────────────────────────────────────────────
// MODULE 1 — Quality Philosophy Timeline
// ─────────────────────────────────────────────
export function Module01_QualityTimeline() {
  const [active, setActive] = useState(null);
  const events = [
    { year:1920, name:"Shewhart", title:"Statistical Control", color:"#3b82f6", desc:"Walter Shewhart develops control charts at Bell Labs — the foundation of SPC. Introduces PDCA cycle." },
    { year:1950, name:"Deming", title:"14 Principles", color:"#8b5cf6", desc:"W. Edwards Deming introduces statistical methods to Japan. His 14 principles transform Toyota and launch TQM." },
    { year:1954, name:"Juran", title:"Quality Trilogy", color:"#10b981", desc:"Joseph Juran defines quality planning, quality control, and quality improvement as an integrated management system." },
    { year:1979, name:"Crosby", title:"Zero Defects", color:"#f59e0b", desc:"Philip Crosby publishes 'Quality is Free' — argues prevention costs less than failure. Zero defects as a goal." },
    { year:1987, name:"ISO 9001", title:"Global Standard", color:"#ef4444", desc:"First ISO 9001 published. Quality management systems become globally standardized and auditable." },
    { year:2000, name:"AS9100", title:"Aerospace QMS", color:"#06b6d4", desc:"AS9100 launched for aerospace/defense. Adds configuration management, key characteristics, FOD prevention to ISO 9001." },
    { year:2015, name:"Risk-Based", title:"ISO 9001:2015", color:"#f97316", desc:"ISO 9001 revision introduces risk-based thinking, context of organization, and removes preventive action as separate clause." },
  ];
  return wrap(<>
    <div style={{marginBottom:20}}>
      <span style={S.badge("#3b82f6")}>MODULE 1</span>
      <h1 style={{...S.h1,marginTop:8}}>History of Quality Management</h1>
      <p style={{color:"#64748b",fontSize:13,margin:"4px 0 0"}}>Click any milestone to explore its significance</p>
    </div>
    <div style={S.card}>
      <div style={{position:"relative",paddingTop:40}}>
        <div style={{position:"absolute",top:60,left:20,right:20,height:3,background:"linear-gradient(90deg,#3b82f6,#8b5cf6,#10b981,#f59e0b,#ef4444,#06b6d4,#f97316)",borderRadius:2}}/>
        <div style={{display:"flex",justifyContent:"space-between",position:"relative"}}>
          {events.map((e,i) => (
            <div key={i} onClick={()=>setActive(active===i?null:i)} style={{display:"flex",flexDirection:"column",alignItems:"center",cursor:"pointer",width:110}}>
              <div style={{fontSize:11,fontWeight:700,color:e.color,marginBottom:6}}>{e.year}</div>
              <div style={{width:16,height:16,borderRadius:"50%",background:e.color,border:"3px solid #0f172a",boxShadow:`0 0 12px ${e.color}60`,zIndex:1,transition:"transform 0.2s",transform:active===i?"scale(1.5)":"scale(1)"}}/>
              <div style={{marginTop:8,fontSize:11,fontWeight:700,color:active===i?e.color:"#94a3b8",textAlign:"center"}}>{e.name}</div>
              <div style={{fontSize:10,color:"#475569",textAlign:"center"}}>{e.title}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
    {active!==null && (
      <div style={{...S.card,border:`1px solid ${events[active].color}50`,background:"#1e293b"}}>
        <div style={{display:"flex",gap:12,alignItems:"flex-start"}}>
          <div style={{width:48,height:48,borderRadius:10,background:events[active].color+"20",border:`1px solid ${events[active].color}40`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,fontWeight:800,color:events[active].color,flexShrink:0}}>{events[active].year}</div>
          <div>
            <h3 style={{margin:"0 0 4px",color:"#f8fafc"}}>{events[active].name} — {events[active].title}</h3>
            <p style={{margin:0,color:"#94a3b8",fontSize:14,lineHeight:1.6}}>{events[active].desc}</p>
          </div>
        </div>
      </div>
    )}
    <div style={S.card}>
      <div style={S.label}>Deming's 14 Principles — Quick Reference</div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:8}}>
        {["Create constancy of purpose","Adopt the new philosophy","Cease dependence on inspection","End lowest-tender contracts","Improve constantly","Institute training on the job","Institute leadership","Drive out fear","Break down department barriers","Eliminate slogans","Eliminate management by numbers","Remove barriers to pride in work","Institute education & self-improvement","Put everyone to work on transformation"].map((p,i)=>(
          <div key={i} style={{display:"flex",gap:8,padding:"8px 10px",background:DARK,borderRadius:6,border:"1px solid #1e293b"}}>
            <span style={{color:"#3b82f6",fontWeight:700,fontSize:12,minWidth:18}}>{i+1}.</span>
            <span style={{fontSize:12,color:"#94a3b8",lineHeight:1.4}}>{p}</span>
          </div>
        ))}
      </div>
    </div>
  </>);
}


// ─────────────────────────────────────────────
// MODULE 2 — QMS Document Hierarchy
// ─────────────────────────────────────────────
export function Module02_QMSHierarchy() {
  const [active, setActive] = useState(null);
  const levels = [
    { level:"Level 1", title:"Quality Manual / Policy", color:"#ef4444", width:"40%", desc:"Sets the organization's quality policy, objectives, and commitment. References the QMS structure. Required by ISO 9001/AS9100.", examples:["Quality Policy Statement","Quality Manual","Management Review Minutes"] },
    { level:"Level 2", title:"Procedures", color:"#f97316", width:"60%", desc:"Describes WHO does WHAT and WHEN. Cross-departmental processes. Written at department manager level.", examples:["Document Control Procedure","CAPA Procedure","Internal Audit Procedure","Nonconformance Procedure"] },
    { level:"Level 3", title:"Work Instructions", color:"#f59e0b", width:"75%", desc:"Step-by-step HOW TO. Written for the operator/inspector. Must be at the point of use.", examples:["CMM Setup Instruction","First Piece Inspection Checklist","Gauge Calibration WI","8D Problem Solving Form"] },
    { level:"Level 4", title:"Records & Forms", color:"#10b981", width:"90%", desc:"Objective Quality Evidence (OQE). Proof that the QMS is working. Must be retained per contract requirements.", examples:["Inspection Reports","Calibration Records","Training Records","FAIRs","Certificates of Conformance"] },
  ];
  return wrap(<>
    <div style={{marginBottom:20}}>
      <span style={S.badge("#10b981")}>MODULE 2</span>
      <h1 style={{...S.h1,marginTop:8}}>QMS Documentation Hierarchy</h1>
      <p style={{color:"#64748b",fontSize:13,margin:"4px 0 0"}}>Click each level to see requirements and examples</p>
    </div>
    <div style={S.card}>
      <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:4,padding:"8px 0"}}>
        {levels.map((l,i)=>(
          <div key={i} onClick={()=>setActive(active===i?null:i)}
            style={{width:l.width,background:active===i?l.color+"30":l.color+"15",border:`2px solid ${active===i?l.color:l.color+"50"}`,borderRadius:8,padding:"12px 20px",cursor:"pointer",transition:"all 0.2s",textAlign:"center"}}>
            <div style={{fontSize:10,color:l.color,fontWeight:700,letterSpacing:1}}>{l.level}</div>
            <div style={{fontSize:14,fontWeight:700,color:"#f8fafc",marginTop:2}}>{l.title}</div>
          </div>
        ))}
      </div>
    </div>
    {active!==null && (
      <div style={{...S.card,border:`1px solid ${levels[active].color}40`}}>
        <div style={{fontSize:11,color:levels[active].color,fontWeight:700,letterSpacing:1,marginBottom:8}}>{levels[active].level} — {levels[active].title}</div>
        <p style={{color:"#94a3b8",fontSize:14,lineHeight:1.6,margin:"0 0 12px"}}>{levels[active].desc}</p>
        <div style={S.label}>Example Documents</div>
        <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
          {levels[active].examples.map((e,i)=>(
            <span key={i} style={S.pill(levels[active].color)}>{e}</span>
          ))}
        </div>
      </div>
    )}
  </>);
}


// ─────────────────────────────────────────────
// MODULE 3 — ISO 9001 Clause Map
// ─────────────────────────────────────────────
export function Module03_ISO9001Clauses() {
  const [active, setActive] = useState(null);
  const clauses = [
    { num:"4", title:"Context of the Organization", color:"#3b82f6", req:"Understand internal/external issues, interested parties, QMS scope", key:"Clause 4 establishes WHY the QMS exists and what it covers." },
    { num:"5", title:"Leadership", color:"#8b5cf6", req:"Top management commitment, quality policy, organizational roles", key:"Management must personally drive quality — cannot delegate accountability." },
    { num:"6", title:"Planning", color:"#10b981", req:"Risk-based thinking, quality objectives, planning for changes", key:"Replace preventive action with proactive risk identification upfront." },
    { num:"7", title:"Support", color:"#f59e0b", req:"Resources, competence, awareness, communication, documented info", key:"Document control and records management live here." },
    { num:"8", title:"Operation", color:"#ef4444", req:"Operational planning, customer requirements, design, production control", key:"The 'doing' clause — where manufacturing quality controls are defined." },
    { num:"9", title:"Performance Evaluation", color:"#06b6d4", req:"Monitoring, measurement, internal audit, management review", key:"How you know the QMS is working — data-driven evaluation." },
    { num:"10", title:"Improvement", color:"#f97316", req:"Nonconformity, corrective action, continual improvement", key:"Close the PDCA loop — every problem drives permanent improvement." },
  ];
  return wrap(<>
    <div style={{marginBottom:20}}>
      <span style={S.badge("#3b82f6")}>MODULE 3</span>
      <h1 style={{...S.h1,marginTop:8}}>ISO 9001:2015 Clause Structure</h1>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10,marginBottom:16}}>
      {clauses.map((c,i)=>(
        <div key={i} onClick={()=>setActive(active===i?null:i)}
          style={{...S.card,marginBottom:0,cursor:"pointer",border:`1px solid ${active===i?c.color:"#334155"}`,background:active===i?c.color+"15":"#1e293b",transition:"all 0.2s"}}>
          <div style={{fontSize:28,fontWeight:800,color:c.color,marginBottom:4}}>§{c.num}</div>
          <div style={{fontSize:12,fontWeight:700,color:"#f1f5f9",lineHeight:1.3}}>{c.title}</div>
        </div>
      ))}
    </div>
    {active!==null && (
      <div style={{...S.card,border:`1px solid ${clauses[active].color}50`}}>
        <div style={{fontSize:11,color:clauses[active].color,fontWeight:700,letterSpacing:1,marginBottom:8}}>CLAUSE {clauses[active].num} — {clauses[active].title.toUpperCase()}</div>
        <div style={{fontSize:13,color:"#94a3b8",marginBottom:10}}><strong style={{color:"#f1f5f9"}}>Requirements: </strong>{clauses[active].req}</div>
        <div style={{padding:"10px 14px",background:DARK,borderRadius:8,border:`1px solid ${clauses[active].color}30`,fontSize:13,color:"#f1f5f9"}}>
          💡 <strong>Key insight: </strong>{clauses[active].key}
        </div>
      </div>
    )}
  </>);
}


// ─────────────────────────────────────────────
// MODULE 4 — AS9100 vs ISO 9001 Delta
// ─────────────────────────────────────────────
export function Module04_AS9100Delta() {
  const [filter, setFilter] = useState("all");
  const deltas = [
    { topic:"Configuration Management", type:"added", impact:"High", desc:"AS9100 requires formal configuration management — controlling part numbers, revisions, and changes throughout the product lifecycle." },
    { topic:"Key Characteristics", type:"added", impact:"High", desc:"Must identify and specially control features critical to fit, form, function, or safety. Requires enhanced inspection and SPC." },
    { topic:"FOD Prevention", type:"added", impact:"High", desc:"Foreign Object Damage prevention program required. Inspections, controls, and documentation of FOD checks." },
    { topic:"First Article Inspection", type:"added", impact:"High", desc:"AS9102 FAIR required for new parts, changes, or production lapses. All three forms must be completed and customer-approved." },
    { topic:"Operational Risk Management", type:"enhanced", impact:"High", desc:"More rigorous than ISO 9001 — must address product safety, counterfeit parts, and human factors in aerospace context." },
    { topic:"Customer Flow-Down", type:"enhanced", impact:"High", desc:"All applicable customer and regulatory requirements must flow down through the supply chain systematically." },
    { topic:"Product/Process Validation", type:"enhanced", impact:"Med", desc:"Special processes must be validated and revalidated. NADCAP certification required for certain special processes." },
    { topic:"Record Retention", type:"enhanced", impact:"Med", desc:"AS9100 records must be retained longer than commercial — often life of the aircraft plus additional years per contract." },
    { topic:"Competency Requirements", type:"enhanced", impact:"Med", desc:"Personnel affecting quality must be qualified against specific criteria. More formal than ISO 9001 expectations." },
    { topic:"Supplier Control", type:"enhanced", impact:"High", desc:"AS9100 requires more rigorous supplier qualification, flow-down of requirements, and monitoring than ISO 9001." },
  ];
  const filtered = filter==="all" ? deltas : deltas.filter(d=>d.type===filter);
  const colors = { added:"#ef4444", enhanced:"#f59e0b" };
  return wrap(<>
    <div style={{marginBottom:20}}>
      <span style={S.badge("#06b6d4")}>MODULE 4</span>
      <h1 style={{...S.h1,marginTop:8}}>AS9100 — What's Added Beyond ISO 9001</h1>
    </div>
    <div style={{display:"flex",gap:8,marginBottom:16}}>
      {["all","added","enhanced"].map(f=>(
        <button key={f} onClick={()=>setFilter(f)} style={{background:filter===f?"#1d4ed820":"#1e293b",border:`1px solid ${filter===f?"#3b82f6":"#334155"}`,borderRadius:6,padding:"6px 14px",color:filter===f?"#60a5fa":"#94a3b8",fontSize:12,cursor:"pointer",fontFamily:"inherit",textTransform:"capitalize"}}>{f==="all"?"All Requirements":f==="added"?"New in AS9100":"Enhanced from ISO"}</button>
      ))}
    </div>
    <div style={{display:"flex",flexDirection:"column",gap:8}}>
      {filtered.map((d,i)=>(
        <div key={i} style={{...S.card,marginBottom:0,display:"flex",gap:12,alignItems:"flex-start"}}>
          <span style={{...S.pill(colors[d.type]),flexShrink:0,marginTop:2}}>{d.type==="added"?"NEW":"ENHANCED"}</span>
          <div style={{flex:1}}>
            <div style={{fontSize:13,fontWeight:700,color:"#f8fafc",marginBottom:4}}>{d.topic}</div>
            <div style={{fontSize:12,color:"#94a3b8",lineHeight:1.5}}>{d.desc}</div>
          </div>
          <span style={{...S.pill(d.impact==="High"?"#ef4444":"#f59e0b"),flexShrink:0,fontSize:10}}>{d.impact} Impact</span>
        </div>
      ))}
    </div>
  </>);
}


// ─────────────────────────────────────────────
// MODULE 5 — Defense Contracting Flow-Down
// ─────────────────────────────────────────────
export function Module05_DefenseFlowDown() {
  const [step, setStep] = useState(0);
  const chain = [
    { entity:"DoD / Government", color:"#ef4444", icon:"🏛️", reqs:["DFARS clauses","MIL-STD requirements","ITAR controls","FAR quality clauses","DCMA oversight rights"] },
    { entity:"Prime Contractor (e.g. DRS Technologies)", color:"#f97316", icon:"🏭", reqs:["AS9100 Rev D compliance","FAIR per AS9102","OQE with each shipment","Certificate of Conformance","Counterfeit parts prevention (AS5553)"] },
    { entity:"CAMCO Manufacturing", color:"#3b82f6", icon:"🔧", reqs:["Flow down all applicable requirements","Special process NADCAP approval","Lot traceability documentation","CMM inspection records","COC on every shipment"] },
    { entity:"CAMCO Suppliers", color:"#10b981", icon:"📦", reqs:["SCAR response required","AS9100 or equivalent","Special process certs (NADCAP)","Material certifications","CoC flow-through"] },
  ];
  return wrap(<>
    <div style={{marginBottom:20}}>
      <span style={S.badge("#ef4444")}>MODULE 5</span>
      <h1 style={{...S.h1,marginTop:8}}>Defense Contract Quality Flow-Down</h1>
      <p style={{color:"#64748b",fontSize:13,margin:"4px 0 0"}}>Requirements cascade from government through every tier</p>
    </div>
    <div style={{display:"flex",flexDirection:"column",gap:4,marginBottom:16}}>
      {chain.map((c,i)=>(
        <div key={i}>
          <div onClick={()=>setStep(step===i?-1:i)} style={{display:"flex",alignItems:"center",gap:12,padding:"14px 18px",background:step===i?c.color+"20":"#1e293b",border:`1px solid ${step===i?c.color:"#334155"}`,borderRadius:10,cursor:"pointer",transition:"all 0.2s"}}>
            <span style={{fontSize:24}}>{c.icon}</span>
            <div style={{flex:1}}>
              <div style={{fontWeight:700,color:step===i?c.color:"#f1f5f9",fontSize:15}}>{c.entity}</div>
              <div style={{fontSize:11,color:"#64748b"}}>Tier {i+1} — click to see requirements</div>
            </div>
            <span style={{color:"#475569",fontSize:18}}>{step===i?"▼":"▶"}</span>
          </div>
          {step===i && (
            <div style={{background:DARK,border:`1px solid ${c.color}30`,borderTop:"none",borderRadius:"0 0 10px 10px",padding:"12px 18px",display:"flex",flexWrap:"wrap",gap:8}}>
              {c.reqs.map((r,j)=>(<span key={j} style={S.pill(c.color)}>{r}</span>))}
            </div>
          )}
          {i<chain.length-1 && <div style={{textAlign:"center",fontSize:18,color:"#334155",margin:"2px 0"}}>↓</div>}
        </div>
      ))}
    </div>
    <div style={{...S.card,background:"#1a0505",border:"1px solid #ef444440"}}>
      <div style={{fontSize:11,color:"#ef4444",fontWeight:700,letterSpacing:1,marginBottom:8}}>⚠ COUNTERFEIT PARTS — KEY REQUIREMENT</div>
      <p style={{fontSize:13,color:"#fca5a5",margin:0,lineHeight:1.6}}>AS5553 (electronic) and AS6174 (non-electronic) require a documented counterfeit parts prevention program. Only purchase from OEMs, authorized distributors, or franchised dealers. Certificate of conformance alone is NOT sufficient traceability for defense parts.</p>
    </div>
  </>);
}


// ─────────────────────────────────────────────
// MODULE 7 — GD&T Symbol Reference
// ─────────────────────────────────────────────
export function Module07_GDT() {
  const [active, setActive] = useState(null);
  const symbols = [
    { sym:"—", name:"Straightness", cat:"Form", color:"#3b82f6", desc:"Controls how straight a line or axis is. No datum required.", example:"Shaft axis must be straight within 0.005\"" },
    { sym:"□", name:"Flatness", cat:"Form", color:"#3b82f6", desc:"Controls surface flatness — must lie between two parallel planes. No datum required.", example:"Mating surface flat within 0.002\"" },
    { sym:"○", name:"Circularity", cat:"Form", color:"#3b82f6", desc:"Controls roundness of each cross-section of a cylinder or cone. No datum required.", example:"Each cross-section must be round within 0.001\"" },
    { sym:"⌭", name:"Cylindricity", cat:"Form", color:"#3b82f6", desc:"Controls both roundness AND straightness of a cylinder simultaneously.", example:"Bearing journal cylindrical within 0.0005\"" },
    { sym:"⌒", name:"Profile of Line", cat:"Profile", color:"#8b5cf6", desc:"Controls 2D cross-section profile. Can be applied with or without datum.", example:"Contour profile within 0.010\" bilateral" },
    { sym:"⌓", name:"Profile of Surface", cat:"Profile", color:"#8b5cf6", desc:"Controls 3D surface profile — most powerful GD&T control.", example:"Aerodynamic surface within 0.020\" all around" },
    { sym:"∠", name:"Angularity", cat:"Orientation", color:"#10b981", desc:"Controls angle of a surface or axis relative to a datum. Requires datum.", example:"Angled face at 30° ±0.5° to datum A" },
    { sym:"⊥", name:"Perpendicularity", cat:"Orientation", color:"#10b981", desc:"Controls 90° relationship to a datum. Most common orientation control.", example:"Bore axis perpendicular to datum A within 0.001\"" },
    { sym:"∥", name:"Parallelism", cat:"Orientation", color:"#10b981", desc:"Controls parallel relationship to a datum. Requires datum.", example:"Rail surface parallel to datum A within 0.003\"" },
    { sym:"⊕", name:"True Position", cat:"Location", color:"#ef4444", desc:"Controls location of features relative to datums. Most widely used GD&T symbol in manufacturing.", example:"Hole pattern located within ⌀0.014\" at MMC to datums A|B|C" },
    { sym:"◎", name:"Concentricity", cat:"Location", color:"#ef4444", desc:"Controls median points of a cylinder to a datum axis. Very difficult to measure — usually replaced by runout.", example:"Inner diameter concentric to OD within 0.002\"" },
    { sym:"⌖", name:"Symmetry", cat:"Location", color:"#ef4444", desc:"Controls median plane symmetry. Rarely used — typically replaced by position.", example:"Slot symmetric about datum A within 0.004\"" },
    { sym:"↗", name:"Circular Runout", cat:"Runout", color:"#f59e0b", desc:"Controls each cross-section independently when rotated about datum axis.", example:"Circular runout 0.002\" to datum A-B" },
    { sym:"⟲", name:"Total Runout", cat:"Runout", color:"#f59e0b", desc:"Controls entire surface simultaneously — most stringent runout control.", example:"Total runout 0.005\" to datum A" },
  ];
  const cats = ["Form","Profile","Orientation","Location","Runout"];
  const catColors = { Form:"#3b82f6",Profile:"#8b5cf6",Orientation:"#10b981",Location:"#ef4444",Runout:"#f59e0b" };
  return wrap(<>
    <div style={{marginBottom:20}}>
      <span style={S.badge("#f59e0b")}>MODULE 7</span>
      <h1 style={{...S.h1,marginTop:8}}>GD&T Symbol Reference — ASME Y14.5</h1>
      <p style={{color:"#64748b",fontSize:13,margin:"4px 0 0"}}>Click any symbol to see definition, requirements, and inspection approach</p>
    </div>
    {cats.map(cat=>(
      <div key={cat} style={{marginBottom:16}}>
        <div style={{...S.label,color:catColors[cat]}}>{cat} Controls</div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8}}>
          {symbols.filter(s=>s.cat===cat).map((s,i)=>(
            <div key={i} onClick={()=>setActive(active?.name===s.name?null:s)}
              style={{...S.card,marginBottom:0,cursor:"pointer",border:`1px solid ${active?.name===s.name?s.color:"#334155"}`,background:active?.name===s.name?s.color+"15":"#1e293b",textAlign:"center",transition:"all 0.2s"}}>
              <div style={{fontSize:28,margin:"4px 0 6px",color:s.color}}>{s.sym}</div>
              <div style={{fontSize:12,fontWeight:700,color:"#f1f5f9"}}>{s.name}</div>
            </div>
          ))}
        </div>
      </div>
    ))}
    {active && (
      <div style={{...S.card,border:`1px solid ${active.color}50`,position:"sticky",bottom:16}}>
        <div style={{display:"flex",gap:16,alignItems:"flex-start"}}>
          <div style={{fontSize:40,color:active.color,minWidth:48,textAlign:"center"}}>{active.sym}</div>
          <div style={{flex:1}}>
            <div style={{fontSize:11,color:active.color,fontWeight:700,letterSpacing:1,marginBottom:4}}>{active.cat.toUpperCase()} CONTROL</div>
            <h3 style={{margin:"0 0 6px",color:"#f8fafc"}}>{active.name}</h3>
            <p style={{margin:"0 0 8px",color:"#94a3b8",fontSize:13,lineHeight:1.5}}>{active.desc}</p>
            <div style={{padding:"8px 12px",background:DARK,borderRadius:6,fontSize:12,color:"#60a5fa"}}>
              📐 Example: {active.example}
            </div>
          </div>
        </div>
      </div>
    )}
  </>);
}


// ─────────────────────────────────────────────
// MODULE 8 — Metrology Tool Selector
// ─────────────────────────────────────────────
export function Module08_Metrology() {
  const [feature, setFeature] = useState(null);
  const features = [
    { name:"OD / ID diameter", tools:["Micrometer (OD)","Bore gauge (ID)","CMM","Plug gauge (ID)","Ring gauge (OD)"], tolerance:"Any", notes:"For tight tolerances (<0.001\"), use micrometer or CMM. Go/no-go gauges fastest for production." },
    { name:"Length / depth", tools:["Calipers","Height gauge + surface plate","CMM","Depth micrometer"], tolerance:"±0.001\" and up", notes:"Calipers adequate for ±0.010\"+. Micrometer needed below ±0.002\". CMM for complex relationships." },
    { name:"Thread", tools:["Go/No-Go thread gauge","Optical comparator","CMM with thread cycle","Thread micrometer"], tolerance:"Class 2B/3B", notes:"Go/No-go gauges verify functional fit. Optical comparator verifies thread form and pitch." },
    { name:"Surface finish (Ra)", tools:["Contact profilometer","Non-contact profilometer","Comparison specimens"], tolerance:"Per callout", notes:"Profilometer gives actual Ra value. Comparison specimens ok for rough screening only." },
    { name:"Flatness / Form", tools:["Surface plate + height gauge","CMM","Optical flat (very tight)","Granite straight edge"], tolerance:"<0.001\"", notes:"Surface plate is the foundation of all metrology. Must be certified and maintained at 68°F." },
    { name:"Angle", tools:["Sine bar","CMM","Protractor (rough)","Optical comparator"], tolerance:"±0.1° and tighter", notes:"Sine bar is the precision standard. CMM most flexible. Protractor only for ±0.5°+ tolerance." },
    { name:"True position", tools:["CMM (only reliable method)","Optical comparator (limited)"], tolerance:"<0.010\"", notes:"CMM with correct datum setup is the standard. Must establish datum reference frame correctly in CMM program." },
    { name:"Hardness", tools:["Rockwell tester","Vickers microhardness","Brinell (large parts)"], tolerance:"Per spec", notes:"Rockwell most common for production. Vickers for case depth, thin sections. Always verify tester calibration." },
  ];
  return wrap(<>
    <div style={{marginBottom:20}}>
      <span style={S.badge("#06b6d4")}>MODULE 8</span>
      <h1 style={{...S.h1,marginTop:8}}>Metrology Tool Selection Guide</h1>
      <p style={{color:"#64748b",fontSize:13,margin:"4px 0 0"}}>Select a feature type to see recommended measurement tools</p>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:8,marginBottom:16}}>
      {features.map((f,i)=>(
        <div key={i} onClick={()=>setFeature(feature===i?null:i)}
          style={{...S.card,marginBottom:0,cursor:"pointer",border:`1px solid ${feature===i?"#06b6d4":"#334155"}`,background:feature===i?"#06b6d420":"#1e293b",transition:"all 0.2s"}}>
          <div style={{fontSize:13,fontWeight:700,color:feature===i?"#06b6d4":"#f1f5f9"}}>{f.name}</div>
          <div style={{fontSize:11,color:"#475569",marginTop:2}}>{f.tools.length} tools available</div>
        </div>
      ))}
    </div>
    {feature!==null && (
      <div style={{...S.card,border:"1px solid #06b6d440"}}>
        <div style={{fontSize:11,color:"#06b6d4",fontWeight:700,letterSpacing:1,marginBottom:10}}>RECOMMENDED TOOLS — {features[feature].name.toUpperCase()}</div>
        <div style={{display:"flex",flexWrap:"wrap",gap:6,marginBottom:12}}>
          {features[feature].tools.map((t,i)=>(
            <span key={i} style={{...S.pill("#06b6d4"),fontSize:12,padding:"6px 14px"}}>{t}</span>
          ))}
        </div>
        <div style={{padding:"10px 14px",background:DARK,borderRadius:8,fontSize:13,color:"#94a3b8",lineHeight:1.6}}>
          💡 {features[feature].notes}
        </div>
      </div>
    )}
    <div style={{...S.card,border:"1px solid #334155"}}>
      <div style={S.label}>Gage Lab Environment Standards</div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
        {[
          { param:"Temperature", value:"68°F ± 2°F", note:"Steel expands 6.5µin/in/°F" },
          { param:"Humidity", value:"45-55% RH", note:"Prevents rust and gauge drift" },
          { param:"Vibration", value:"Isolated", note:"CMM must be on isolation mount" },
        ].map((e,i)=>(
          <div key={i} style={{background:DARK,borderRadius:8,padding:"12px 14px",border:"1px solid #1e293b"}}>
            <div style={{fontSize:11,color:"#64748b",marginBottom:4}}>{e.param}</div>
            <div style={{fontSize:16,fontWeight:700,color:"#06b6d4",marginBottom:4}}>{e.value}</div>
            <div style={{fontSize:11,color:"#475569"}}>{e.note}</div>
          </div>
        ))}
      </div>
    </div>
  </>);
}


// ─────────────────────────────────────────────
// MODULE 11 — Normal Distribution Bell Curve
// ─────────────────────────────────────────────
export function Module11_Statistics() {
  const [sigma, setSigma] = useState(1);
  const mean = 0;
  const normal = (x, m, s) => (1/(s*Math.sqrt(2*Math.PI)))*Math.exp(-0.5*((x-m)/s)**2);
  const data = Array.from({length:121},(_,i)=>{
    const x = -3 + i*0.05;
    return { x:parseFloat(x.toFixed(2)), y:parseFloat(normal(x,mean,1).toFixed(4)) };
  });
  const zones = [
    { label:"68.27%", range:"±1σ", color:"#3b82f6", from:-1, to:1 },
    { label:"95.45%", range:"±2σ", color:"#8b5cf6", from:-2, to:2 },
    { label:"99.73%", range:"±3σ", color:"#10b981", from:-3, to:3 },
  ];
  return wrap(<>
    <div style={{marginBottom:20}}>
      <span style={S.badge("#8b5cf6")}>MODULE 11</span>
      <h1 style={{...S.h1,marginTop:8}}>Normal Distribution & the Empirical Rule</h1>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10,marginBottom:16}}>
      {zones.map((z,i)=>(
        <div key={i} style={{...S.card,marginBottom:0,textAlign:"center",border:`1px solid ${z.color}40`}}>
          <div style={{fontSize:28,fontWeight:800,color:z.color}}>{z.label}</div>
          <div style={{fontSize:13,color:"#94a3b8"}}>of data within</div>
          <div style={{fontSize:16,fontWeight:700,color:"#f1f5f9"}}>{z.range}</div>
        </div>
      ))}
    </div>
    <div style={S.card}>
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={data} barCategoryGap="0%">
          <XAxis dataKey="x" tick={{fill:"#64748b",fontSize:10}} tickFormatter={v=>v%1===0?`${v}σ`:""} />
          <YAxis hide />
          <Bar dataKey="y" radius={0}>
            {data.map((d,i)=>(
              <Cell key={i} fill={Math.abs(d.x)<=1?"#3b82f6":Math.abs(d.x)<=2?"#8b5cf6":Math.abs(d.x)<=3?"#10b981":"#1e293b"} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      <div style={{display:"flex",justifyContent:"center",gap:20,marginTop:8}}>
        {[["#3b82f6","Within ±1σ"],["#8b5cf6","Within ±2σ"],["#10b981","Within ±3σ"]].map(([c,l])=>(
          <div key={l} style={{display:"flex",alignItems:"center",gap:6,fontSize:11,color:"#64748b"}}>
            <div style={{width:10,height:10,background:c,borderRadius:2}}/>{l}
          </div>
        ))}
      </div>
    </div>
    <div style={S.card}>
      <div style={S.label}>Application to Manufacturing</div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:8}}>
        {[
          { title:"Cpk = 1.00", note:"±3σ = spec limits → 0.27% defective (2700 PPM)", color:"#ef4444" },
          { title:"Cpk = 1.33", note:"±4σ = spec limits → 0.0063% defective (63 PPM)", color:"#f59e0b" },
          { title:"Cpk = 1.67", note:"±5σ = spec limits → 0.00006% defective (0.6 PPM)", color:"#10b981" },
          { title:"Cpk = 2.00 (6σ)", note:"±6σ = spec limits → 3.4 PPM (with 1.5σ shift)", color:"#3b82f6" },
        ].map((c,i)=>(
          <div key={i} style={{padding:"10px 12px",background:DARK,borderRadius:8,border:`1px solid ${c.color}30`}}>
            <div style={{fontWeight:700,color:c.color,fontSize:13,marginBottom:3}}>{c.title}</div>
            <div style={{fontSize:12,color:"#94a3b8"}}>{c.note}</div>
          </div>
        ))}
      </div>
    </div>
  </>);
}


// ─────────────────────────────────────────────
// MODULE 12 — SPC Control Chart (Interactive)
// ─────────────────────────────────────────────
export function Module12_SPC() {
  const gen = useCallback(()=>{
    const mean=1.2500, s=0.0008;
    return Array.from({length:25},(_,i)=>{
      const u1=Math.random(),u2=Math.random();
      const z=Math.sqrt(-2*Math.log(u1))*Math.cos(2*Math.PI*u2);
      let v=mean+s*z;
      if(i===7) v=mean+3.4*s;
      if(i===14) v=mean-3.2*s;
      if(i>=16&&i<=22) v=mean+(i-15)*0.00015;
      return { n:i+1, v:parseFloat(v.toFixed(5)), UCL:parseFloat((mean+3*s).toFixed(5)), LCL:parseFloat((mean-3*s).toFixed(5)), CL:parseFloat(mean.toFixed(5)), ooc:v>mean+3*s||v<mean-3*s };
    });
  },[]);
  const [data,setData]=useState(gen);
  const [sel,setSel]=useState(null);
  const CustomDot=({cx,cy,payload})=>{
    if(payload.ooc) return <circle cx={cx} cy={cy} r={7} fill="#ef4444" stroke="#fff" strokeWidth={2}/>;
    return <circle cx={cx} cy={cy} r={4} fill="#3b82f6" stroke="#fff" strokeWidth={1.5}/>;
  };
  const ooc=data.filter(d=>d.ooc).length;
  const cpk=parseFloat((Math.min((data[0].UCL-data[0].CL),(data[0].CL-data[0].LCL))/(3*0.0008)).toFixed(2));
  return wrap(<>
    <div style={{marginBottom:20}}>
      <span style={S.badge("#3b82f6")}>MODULE 12</span>
      <h1 style={{...S.h1,marginTop:8}}>Statistical Process Control — I-Chart</h1>
      <p style={{color:"#64748b",fontSize:13,margin:"4px 0 0"}}>Shaft OD — Nominal: 1.2500" ±0.0025"</p>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10,marginBottom:16}}>
      {[["CL",data[0].CL.toFixed(4)+'"',"#34d399"],["UCL",data[0].UCL.toFixed(4)+'"',"#ef4444"],["LCL",data[0].LCL.toFixed(4)+'"',"#ef4444"],["Cpk",cpk,cpk>=1.33?"#34d399":"#ef4444"]].map(([l,v,c])=>(
        <div key={l} style={{...S.card,marginBottom:0,textAlign:"center"}}>
          <div style={{fontSize:10,color:"#64748b",letterSpacing:1}}>{l}</div>
          <div style={{fontSize:18,fontWeight:700,color:c,marginTop:4}}>{v}</div>
        </div>
      ))}
    </div>
    <div style={S.card}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
        <span style={{fontSize:13,color:"#94a3b8",fontWeight:600}}>25 SAMPLES — {ooc} OUT OF CONTROL</span>
        <button onClick={()=>{setData(gen());setSel(null);}} style={{background:"#334155",border:"1px solid #475569",borderRadius:6,padding:"5px 12px",color:"#94a3b8",fontSize:11,cursor:"pointer",fontFamily:"inherit"}}>↻ New Data</button>
      </div>
      <ResponsiveContainer width="100%" height={260}>
        <LineChart data={data} onClick={e=>e?.activePayload&&setSel(e.activePayload[0]?.payload)}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e3a5f"/>
          <XAxis dataKey="n" stroke="#475569" tick={{fill:"#64748b",fontSize:11}}/>
          <YAxis stroke="#475569" tick={{fill:"#64748b",fontSize:10}} tickFormatter={v=>v.toFixed(4)} width={65}/>
          <Tooltip formatter={v=>[v.toFixed(5)+'"',"Value"]} contentStyle={{background:"#1e293b",border:"1px solid #334155",borderRadius:8,color:"#f1f5f9"}}/>
          <ReferenceLine y={data[0].UCL} stroke="#ef4444" strokeWidth={2} label={{value:"UCL",position:"right",fill:"#ef4444",fontSize:11}}/>
          <ReferenceLine y={data[0].LCL} stroke="#ef4444" strokeWidth={2} label={{value:"LCL",position:"right",fill:"#ef4444",fontSize:11}}/>
          <ReferenceLine y={data[0].CL} stroke="#34d399" strokeDasharray="6 3" strokeWidth={2} label={{value:"CL",position:"right",fill:"#34d399",fontSize:11}}/>
          <Line type="monotone" dataKey="v" stroke="#3b82f6" strokeWidth={2} dot={<CustomDot/>}/>
        </LineChart>
      </ResponsiveContainer>
    </div>
    {sel&&(
      <div style={{...S.card,border:`1px solid ${sel.ooc?"#ef4444":"#334155"}`}}>
        <div style={{fontSize:13,color:"#f1f5f9"}}><strong>Sample {sel.n}:</strong> {sel.v.toFixed(5)}" — <span style={{color:sel.ooc?"#ef4444":"#34d399",fontWeight:700}}>{sel.ooc?"⚠ OUT OF CONTROL — Stop and investigate!":"✓ In statistical control"}</span></div>
      </div>
    )}
    <div style={S.card}>
      <div style={S.label}>Western Electric Rules</div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:8}}>
        {["1 point beyond 3σ","8 consecutive points same side of CL","6 points in a row trending up or down","2 of 3 consecutive points beyond 2σ","4 of 5 points beyond 1σ","15 points in a row within ±1σ (hugging)","8 points both sides of CL with none in Zone C","14 points alternating up and down"].map((r,i)=>(
          <div key={i} style={{display:"flex",gap:8,padding:"8px 10px",background:DARK,borderRadius:6}}>
            <span style={{color:"#ef4444",fontWeight:700,minWidth:16,fontSize:12}}>R{i+1}</span>
            <span style={{fontSize:12,color:"#94a3b8"}}>{r}</span>
          </div>
        ))}
      </div>
    </div>
  </>);
}


// ─────────────────────────────────────────────
// MODULE 13 — Gauge R&R Results Interpreter
// ─────────────────────────────────────────────
export function Module13_GaugeRR() {
  const [grr, setGrr] = useState(18);
  const [ndc, setNdc] = useState(4);
  const status = grr<10?"Excellent":grr<30?"Acceptable — may be ok depending on application":"Unacceptable — gauge system must be improved";
  const statusColor = grr<10?"#34d399":grr<30?"#f59e0b":"#ef4444";
  const ndcStatus = ndc>=5?"Adequate":ndc>=2?"Marginal":"Inadequate — cannot distinguish parts";
  const ndcColor = ndc>=5?"#34d399":ndc>=2?"#f59e0b":"#ef4444";
  return wrap(<>
    <div style={{marginBottom:20}}>
      <span style={S.badge("#10b981")}>MODULE 13</span>
      <h1 style={{...S.h1,marginTop:8}}>Measurement System Analysis — Gauge R&R</h1>
      <p style={{color:"#64748b",fontSize:13,margin:"4px 0 0"}}>Adjust sliders to interpret %GRR and ndc results</p>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16,marginBottom:16}}>
      <div style={S.card}>
        <div style={S.label}>%GRR (% of Tolerance)</div>
        <div style={{fontSize:48,fontWeight:800,color:statusColor,margin:"8px 0"}}>{grr}%</div>
        <input type="range" min={1} max={50} value={grr} onChange={e=>setGrr(+e.target.value)} style={{width:"100%",accentColor:statusColor,marginBottom:10}}/>
        <div style={{padding:"8px 12px",background:DARK,borderRadius:8,fontSize:12,color:statusColor,fontWeight:600}}>{status}</div>
        <div style={{marginTop:10,display:"flex",flexDirection:"column",gap:4}}>
          {[["<10%","#34d399","Excellent — use gauge"],["10-30%","#f59e0b","Acceptable — evaluate"],["≥30%","#ef4444","Unacceptable — fix gauge"]].map(([r,c,l])=>(
            <div key={r} style={{display:"flex",gap:8,alignItems:"center",fontSize:11}}>
              <div style={{width:8,height:8,borderRadius:2,background:c,flexShrink:0}}/>
              <span style={{color:c,fontWeight:700,minWidth:44}}>{r}</span>
              <span style={{color:"#64748b"}}>{l}</span>
            </div>
          ))}
        </div>
      </div>
      <div style={S.card}>
        <div style={S.label}>ndc (Number of Distinct Categories)</div>
        <div style={{fontSize:48,fontWeight:800,color:ndcColor,margin:"8px 0"}}>{ndc}</div>
        <input type="range" min={1} max={10} value={ndc} onChange={e=>setNdc(+e.target.value)} style={{width:"100%",accentColor:ndcColor,marginBottom:10}}/>
        <div style={{padding:"8px 12px",background:DARK,borderRadius:8,fontSize:12,color:ndcColor,fontWeight:600}}>{ndcStatus}</div>
        <div style={{marginTop:10,display:"flex",flexDirection:"column",gap:4}}>
          {[["≥5","#34d399","Can distinguish 5+ categories"],["2-4","#f59e0b","Limited — marginal use"],["1","#ef4444","Cannot distinguish parts"]].map(([r,c,l])=>(
            <div key={r} style={{display:"flex",gap:8,alignItems:"center",fontSize:11}}>
              <div style={{width:8,height:8,borderRadius:2,background:c,flexShrink:0}}/>
              <span style={{color:c,fontWeight:700,minWidth:28}}>{r}</span>
              <span style={{color:"#64748b"}}>{l}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
    <div style={S.card}>
      <div style={S.label}>Sources of Measurement Variation</div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
        {[
          {src:"Repeatability (EV)",desc:"Same operator, same gauge, same part — variation from gauge itself",color:"#3b82f6"},
          {src:"Reproducibility (AV)",desc:"Different operators using same gauge — variation from operators",color:"#8b5cf6"},
          {src:"Part-to-Part (PV)",desc:"Actual part variation — what we WANT the gauge to measure",color:"#10b981"},
        ].map((s,i)=>(
          <div key={i} style={{background:DARK,borderRadius:8,padding:"12px 14px",border:`1px solid ${s.color}30`}}>
            <div style={{fontSize:12,fontWeight:700,color:s.color,marginBottom:6}}>{s.src}</div>
            <div style={{fontSize:11,color:"#94a3b8",lineHeight:1.5}}>{s.desc}</div>
          </div>
        ))}
      </div>
    </div>
  </>);
}


// ─────────────────────────────────────────────
// MODULE 14 — Fishbone Diagram (simplified embed)
// ─────────────────────────────────────────────
export function Module14_Fishbone() {
  const [sel, setSel] = useState(null);
  const cats = [
    { name:"Man", color:"#3b82f6", icon:"👷", causes:["Untrained inspector","Operator fatigue","Wrong measurement technique","No SOP followed"] },
    { name:"Machine", color:"#8b5cf6", icon:"⚙️", causes:["Tool wear","Spindle runout","Fixture worn","CMM probe error"] },
    { name:"Material", color:"#10b981", icon:"📦", causes:["Wrong alloy received","Heat treat out of spec","Surface contamination","Dimensional variation in stock"] },
    { name:"Method", color:"#f59e0b", icon:"📋", causes:["No control plan","Wrong inspection sequence","SPC not implemented","No first piece inspection"] },
    { name:"Measurement", color:"#ef4444", icon:"📏", causes:["Gauge out of calibration","Poor Gauge R&R","Wrong gauge selected","Environmental error"] },
    { name:"Environment", color:"#06b6d4", icon:"🏭", causes:["Temperature variation","Coolant contamination","Vibration from nearby machines","Chip buildup in fixture"] },
  ];
  return wrap(<>
    <div style={{marginBottom:20}}>
      <span style={S.badge("#ef4444")}>MODULE 14</span>
      <h1 style={{...S.h1,marginTop:8}}>Fishbone (Ishikawa) Diagram — 6M Method</h1>
      <p style={{color:"#64748b",fontSize:13,margin:"4px 0 0"}}>Effect: Dimensional Non-Conformance on Machined Part</p>
    </div>
    <div style={{...S.card,marginBottom:16,textAlign:"center",background:"#200a0a",border:"1px solid #ef444450"}}>
      <div style={{fontSize:14,fontWeight:700,color:"#fca5a5"}}>⚠ PROBLEM / EFFECT</div>
      <div style={{fontSize:18,fontWeight:800,color:"#ef4444",marginTop:4}}>Dimensional Non-Conformance on Machined Part</div>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10,marginBottom:16}}>
      {cats.map((c,i)=>(
        <div key={i} onClick={()=>setSel(sel===i?null:i)}
          style={{...S.card,marginBottom:0,cursor:"pointer",border:`1px solid ${sel===i?c.color:"#334155"}`,background:sel===i?c.color+"15":"#1e293b",transition:"all 0.2s"}}>
          <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:8}}>
            <span style={{fontSize:20}}>{c.icon}</span>
            <span style={{fontWeight:700,color:c.color,fontSize:14}}>{c.name}</span>
          </div>
          {sel===i && (
            <div style={{display:"flex",flexDirection:"column",gap:4}}>
              {c.causes.map((cause,j)=>(
                <div key={j} style={{display:"flex",gap:6,alignItems:"center"}}>
                  <div style={{width:5,height:5,borderRadius:"50%",background:c.color,flexShrink:0}}/>
                  <span style={{fontSize:12,color:"#94a3b8"}}>{cause}</span>
                </div>
              ))}
            </div>
          )}
          {sel!==i && <div style={{fontSize:11,color:"#475569"}}>{c.causes.length} potential causes — click to expand</div>}
        </div>
      ))}
    </div>
    <div style={S.card}>
      <div style={S.label}>5 Whys Integration</div>
      <div style={{display:"flex",flexDirection:"column",gap:6}}>
        {["Why did the non-conformance occur? → Tool wear exceeded offset limit","Why did tool wear exceed limit? → No tool life tracking system","Why was there no tool life tracking? → SPC not implemented on this operation","Why was SPC not implemented? → No control plan existed for this feature","Why was there no control plan? → APQP process was skipped at launch → ROOT CAUSE"].map((s,i)=>(
          <div key={i} style={{display:"flex",gap:10,alignItems:"flex-start",padding:"8px 10px",background:DARK,borderRadius:6,border:i===4?"1px solid #34d39940":"1px solid transparent"}}>
            <span style={{color:i===4?"#34d399":"#3b82f6",fontWeight:700,fontSize:12,minWidth:16}}>{i+1}</span>
            <span style={{fontSize:12,color:i===4?"#34d399":"#94a3b8"}}>{s}</span>
          </div>
        ))}
      </div>
    </div>
  </>);
}


// ─────────────────────────────────────────────
// MODULE 16 — AS9102 FAIR Process Flow
// ─────────────────────────────────────────────
export function Module16_FAIR() {
  const [step, setStep] = useState(0);
  const steps = [
    { num:1, title:"Determine FAIR Requirement", color:"#3b82f6", when:["New part number","First production after design change","Production lapse (typically 2 years)","Change in manufacturing location","Change in special process supplier"], action:"Review customer contract and purchase order for FAIR requirements. Confirm scope with customer if uncertain." },
    { num:2, title:"Form 1 — Design Documentation", color:"#8b5cf6", when:["Compile all drawing revisions","Capture all drawing notes","Identify all referenced specs","Document engineering changes","Verify revision levels match PO"], action:"Every drawing note, tolerance, and specification reference must be documented. Missing items = incomplete FAIR." },
    { num:3, title:"Form 2 — Material & Process", color:"#10b981", when:["Collect material certifications (MTRs)","Obtain special process certs","Verify NADCAP approvals current","Document all sub-tier suppliers","Confirm cert revision levels"], action:"Material certs must trace to the specific lot used. Special process certs must be current and from approved supplier." },
    { num:4, title:"Form 3 — Characteristic Accountability", color:"#f59e0b", when:["List EVERY drawing characteristic","Measure all dimensions","Document actual values (not just pass/fail)","Flag any non-conformances","Complete all GD&T callouts via CMM"], action:"Every single characteristic — dimensions, notes, tolerances, GD&T — must appear on Form 3 with actual measured values." },
    { num:5, title:"FAIR Review & Disposition", color:"#ef4444", when:["Review for completeness","Verify all actuals within tolerance","Disposition any non-conformances","Get engineering sign-off","Prepare submission package"], action:"Non-conformances on FAIR do not automatically reject the part — they require disposition (UAI, rework, scrap, concession)." },
    { num:6, title:"Customer Submission", color:"#06b6d4", when:["Package all three forms","Include supporting documentation","Submit per customer portal or procedure","Respond to review comments","Maintain FAIR on file per retention requirements"], action:"FAIR must be retained for life of part/contract. Customer approval of FAIR is required before production shipments." },
  ];
  return wrap(<>
    <div style={{marginBottom:20}}>
      <span style={S.badge("#f59e0b")}>MODULE 16</span>
      <h1 style={{...S.h1,marginTop:8}}>AS9102 First Article Inspection Report (FAIR)</h1>
      <p style={{color:"#64748b",fontSize:13,margin:"4px 0 0"}}>Step through the complete FAIR process</p>
    </div>
    <div style={{display:"flex",gap:6,marginBottom:16,flexWrap:"wrap"}}>
      {steps.map((s,i)=>(
        <button key={i} onClick={()=>setStep(i)}
          style={{background:step===i?s.color+"25":"#1e293b",border:`1px solid ${step===i?s.color:"#334155"}`,borderRadius:8,padding:"8px 14px",color:step===i?s.color:"#64748b",fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>
          Step {s.num}
        </button>
      ))}
    </div>
    <div style={{...S.card,border:`1px solid ${steps[step].color}50`}}>
      <div style={{display:"flex",gap:12,alignItems:"flex-start",marginBottom:14}}>
        <div style={{width:44,height:44,borderRadius:10,background:steps[step].color+"20",border:`1px solid ${steps[step].color}40`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,fontWeight:800,color:steps[step].color,flexShrink:0}}>{steps[step].num}</div>
        <div>
          <div style={{fontSize:11,color:steps[step].color,fontWeight:700,letterSpacing:1,marginBottom:4}}>STEP {steps[step].num} OF 6</div>
          <h3 style={{margin:0,color:"#f8fafc",fontSize:17}}>{steps[step].title}</h3>
        </div>
      </div>
      <div style={S.label}>Requirements / Checklist</div>
      <div style={{display:"flex",flexDirection:"column",gap:4,marginBottom:12}}>
        {steps[step].when.map((w,i)=>(
          <div key={i} style={{display:"flex",gap:8,padding:"7px 10px",background:DARK,borderRadius:6}}>
            <span style={{color:steps[step].color,fontSize:12}}>☐</span>
            <span style={{fontSize:12,color:"#94a3b8"}}>{w}</span>
          </div>
        ))}
      </div>
      <div style={{padding:"10px 14px",background:DARK,borderRadius:8,border:`1px solid ${steps[step].color}30`,fontSize:13,color:"#f1f5f9",lineHeight:1.6}}>
        💡 <strong>Key point: </strong>{steps[step].action}
      </div>
    </div>
    <div style={{display:"flex",justifyContent:"space-between",gap:8}}>
      <button onClick={()=>setStep(Math.max(0,step-1))} disabled={step===0} style={{flex:1,background:"#1e293b",border:"1px solid #334155",borderRadius:8,padding:"10px",color:step===0?"#334155":"#94a3b8",cursor:step===0?"default":"pointer",fontFamily:"inherit"}}>← Previous</button>
      <button onClick={()=>setStep(Math.min(steps.length-1,step+1))} disabled={step===steps.length-1} style={{flex:1,background:"#1e293b",border:"1px solid #334155",borderRadius:8,padding:"10px",color:step===steps.length-1?"#334155":"#94a3b8",cursor:step===steps.length-1?"default":"pointer",fontFamily:"inherit"}}>Next →</button>
    </div>
  </>);
}


// ─────────────────────────────────────────────
// MODULE 20 — Supplier Scorecard Simulator
// ─────────────────────────────────────────────
export function Module20_SupplierScorecard() {
  const [scores, setScores] = useState({ quality:85, delivery:92, responsiveness:70, certs:100, scar:60 });
  const weights = { quality:0.35, delivery:0.25, responsiveness:0.15, certs:0.15, scar:0.10 };
  const total = Object.keys(scores).reduce((acc,k)=>acc+scores[k]*weights[k],0).toFixed(1);
  const status = total>=90?"Preferred":total>=75?"Approved":total>=60?"Conditional":"Disqualified";
  const statusColor = total>=90?"#34d399":total>=75?"#3b82f6":total>=60?"#f59e0b":"#ef4444";
  const labels = { quality:"Quality (PPM/Defects)", delivery:"On-Time Delivery", responsiveness:"SCAR Response Time", certs:"Certification Currency", scar:"SCAR Closure Rate" };
  return wrap(<>
    <div style={{marginBottom:20}}>
      <span style={S.badge("#10b981")}>MODULE 20</span>
      <h1 style={{...S.h1,marginTop:8}}>Supplier Scorecard Simulator</h1>
      <p style={{color:"#64748b",fontSize:13,margin:"4px 0 0"}}>Adjust scores to see supplier rating calculation</p>
    </div>
    <div style={{...S.card,textAlign:"center",border:`1px solid ${statusColor}50`,marginBottom:16}}>
      <div style={{fontSize:14,color:"#64748b",marginBottom:4}}>Overall Supplier Rating</div>
      <div style={{fontSize:56,fontWeight:800,color:statusColor,lineHeight:1}}>{total}</div>
      <div style={{fontSize:20,fontWeight:700,color:statusColor,marginTop:4}}>{status}</div>
    </div>
    <div style={S.card}>
      {Object.keys(scores).map(k=>(
        <div key={k} style={{marginBottom:16}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
            <div>
              <span style={{fontSize:13,fontWeight:600,color:"#f1f5f9"}}>{labels[k]}</span>
              <span style={{fontSize:11,color:"#475569",marginLeft:8}}>Weight: {(weights[k]*100).toFixed(0)}%</span>
            </div>
            <span style={{fontWeight:700,color:scores[k]>=80?"#34d399":scores[k]>=60?"#f59e0b":"#ef4444"}}>{scores[k]}</span>
          </div>
          <input type="range" min={0} max={100} value={scores[k]} onChange={e=>setScores({...scores,[k]:+e.target.value})}
            style={{width:"100%",accentColor:scores[k]>=80?"#34d399":scores[k]>=60?"#f59e0b":"#ef4444"}}/>
          <div style={{height:4,background:"#0f172a",borderRadius:2,marginTop:4}}>
            <div style={{width:`${scores[k]}%`,height:"100%",background:scores[k]>=80?"#34d399":scores[k]>=60?"#f59e0b":"#ef4444",borderRadius:2,transition:"width 0.3s"}}/>
          </div>
        </div>
      ))}
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8}}>
      {[["≥90","#34d399","Preferred","Reduced incoming inspection"],["75-89","#3b82f6","Approved","Standard oversight"],["60-74","#f59e0b","Conditional","Corrective action plan required"],["<60","#ef4444","Disqualified","Remove from ASL"]].map(([r,c,s,n])=>(
        <div key={r} style={{...S.card,marginBottom:0,border:`1px solid ${c}30`}}>
          <div style={{fontWeight:700,color:c,fontSize:13,marginBottom:3}}>{r} — {s}</div>
          <div style={{fontSize:11,color:"#64748b"}}>{n}</div>
        </div>
      ))}
    </div>
  </>);
}


// ─────────────────────────────────────────────
// MODULE 21 — FMEA RPN Calculator
// ─────────────────────────────────────────────
export function Module21_FMEA() {
  const [rows, setRows] = useState([
    { mode:"Tool breaks mid-cut", effect:"Scrapped part, machine downtime", S:7, O:3, D:4 },
    { mode:"Wrong offset programmed", effect:"Out-of-tolerance dimension", S:8, O:2, D:3 },
    { mode:"Coolant failure", effect:"Surface finish defect, thermal damage", S:6, O:4, D:5 },
    { mode:"Fixture slip", effect:"Dimensional shift, possible crash", S:9, O:2, D:6 },
  ]);
  const update = (i,k,v) => setRows(rows.map((r,j)=>j===i?{...r,[k]:+v}:r));
  const rpnColor = (rpn) => rpn>=200?"#ef4444":rpn>=100?"#f59e0b":rpn>=50?"#3b82f6":"#34d399";
  return wrap(<>
    <div style={{marginBottom:20}}>
      <span style={S.badge("#f97316")}>MODULE 21</span>
      <h1 style={{...S.h1,marginTop:8}}>Process FMEA — RPN Calculator</h1>
      <p style={{color:"#64748b",fontSize:13,margin:"4px 0 0"}}>Adjust Severity, Occurrence, Detection to see Risk Priority Numbers</p>
    </div>
    <div style={{overflowX:"auto",marginBottom:16}}>
      <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
        <thead>
          <tr style={{background:"#0f172a"}}>
            {["Failure Mode","Effect","S (1-10)","O (1-10)","D (1-10)","RPN","Action"].map(h=>(
              <th key={h} style={{padding:"10px 12px",textAlign:"left",color:"#64748b",fontWeight:700,letterSpacing:0.5,borderBottom:"1px solid #334155",fontSize:11}}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r,i)=>{
            const rpn=r.S*r.O*r.D;
            return(
              <tr key={i} style={{borderBottom:"1px solid #1e293b"}}>
                <td style={{padding:"10px 12px",color:"#f1f5f9",fontWeight:600}}>{r.mode}</td>
                <td style={{padding:"10px 12px",color:"#94a3b8"}}>{r.effect}</td>
                {["S","O","D"].map(k=>(
                  <td key={k} style={{padding:"8px 12px"}}>
                    <input type="range" min={1} max={10} value={r[k]} onChange={e=>update(i,k,e.target.value)} style={{width:70,accentColor:k==="S"?"#ef4444":k==="O"?"#f59e0b":"#3b82f6"}}/>
                    <span style={{marginLeft:6,color:k==="S"?"#ef4444":k==="O"?"#f59e0b":"#3b82f6",fontWeight:700}}>{r[k]}</span>
                  </td>
                ))}
                <td style={{padding:"10px 12px"}}>
                  <span style={{fontSize:18,fontWeight:800,color:rpnColor(rpn)}}>{rpn}</span>
                </td>
                <td style={{padding:"10px 12px",color:"#64748b",fontSize:11}}>
                  {rpn>=200?"Immediate action":rpn>=100?"Action required":rpn>=50?"Monitor":rpn>=1?"Acceptable":""}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>
      {[["Severity (S)","#ef4444","10=Hazardous, 8=High, 6=Moderate, 3=Minor, 1=None"],["Occurrence (O)","#f59e0b","10=Almost certain, 7=High, 4=Moderate, 2=Low, 1=Remote"],["Detection (D)","#3b82f6","10=Cannot detect, 7=Low chance, 4=Moderate chance, 1=Almost certain detection"]].map(([t,c,d])=>(
        <div key={t} style={{...S.card,marginBottom:0,border:`1px solid ${c}30`}}>
          <div style={{fontWeight:700,color:c,fontSize:12,marginBottom:6}}>{t}</div>
          <div style={{fontSize:11,color:"#64748b",lineHeight:1.5}}>{d}</div>
        </div>
      ))}
    </div>
  </>);
}


// ─────────────────────────────────────────────
// MODULE 24 — Cost of Quality Dashboard
// ─────────────────────────────────────────────
export function Module24_COQ() {
  const [costs, setCosts] = useState({ prevention:15000, appraisal:22000, internal:45000, external:38000 });
  const total = Object.values(costs).reduce((a,b)=>a+b,0);
  const copq = costs.internal + costs.external;
  const labels = { prevention:"Prevention", appraisal:"Appraisal", internal:"Internal Failure", external:"External Failure" };
  const colors = { prevention:"#34d399", appraisal:"#3b82f6", internal:"#f59e0b", external:"#ef4444" };
  const data = Object.keys(costs).map(k=>({ name:labels[k], value:costs[k], pct:((costs[k]/total)*100).toFixed(1) }));
  return wrap(<>
    <div style={{marginBottom:20}}>
      <span style={S.badge("#34d399")}>MODULE 24</span>
      <h1 style={{...S.h1,marginTop:8}}>Cost of Quality Dashboard</h1>
      <p style={{color:"#64748b",fontSize:13,margin:"4px 0 0"}}>Adjust costs to see COQ breakdown and COPQ impact</p>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:16}}>
      <div style={{...S.card,textAlign:"center",border:"1px solid #334155"}}>
        <div style={{fontSize:11,color:"#64748b",letterSpacing:1}}>TOTAL COST OF QUALITY</div>
        <div style={{fontSize:40,fontWeight:800,color:"#f1f5f9",margin:"4px 0"}}>${(total/1000).toFixed(0)}K</div>
        <div style={{fontSize:12,color:"#64748b"}}>{((total/500000)*100).toFixed(1)}% of revenue (est.)</div>
      </div>
      <div style={{...S.card,textAlign:"center",border:"1px solid #ef444450"}}>
        <div style={{fontSize:11,color:"#64748b",letterSpacing:1}}>COST OF POOR QUALITY (COPQ)</div>
        <div style={{fontSize:40,fontWeight:800,color:"#ef4444",margin:"4px 0"}}>${(copq/1000).toFixed(0)}K</div>
        <div style={{fontSize:12,color:"#ef4444"}}>{((copq/total)*100).toFixed(0)}% of total COQ</div>
      </div>
    </div>
    <div style={S.card}>
      {Object.keys(costs).map(k=>(
        <div key={k} style={{marginBottom:14}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
            <span style={{fontSize:13,fontWeight:600,color:colors[k]}}>{labels[k]}</span>
            <span style={{fontWeight:700,color:"#f1f5f9"}}>${costs[k].toLocaleString()}</span>
          </div>
          <input type="range" min={0} max={100000} step={1000} value={costs[k]} onChange={e=>setCosts({...costs,[k]:+e.target.value})}
            style={{width:"100%",accentColor:colors[k]}}/>
          <div style={{height:6,background:"#0f172a",borderRadius:3,marginTop:4}}>
            <div style={{width:`${(costs[k]/100000)*100}%`,height:"100%",background:colors[k],borderRadius:3,transition:"width 0.3s"}}/>
          </div>
        </div>
      ))}
    </div>
    <div style={{...S.card,border:"1px solid #334155"}}>
      <div style={S.label}>The Prevention Investment Principle</div>
      <div style={{fontSize:13,color:"#94a3b8",lineHeight:1.7}}>
        <strong style={{color:"#34d399"}}>Every $1 spent on prevention</strong> saves $10 in internal failure costs and $100+ in external failure costs (customer returns, warranty, reputation damage). 
        World-class manufacturers target <strong style={{color:"#f1f5f9"}}>COQ below 5% of revenue</strong> with prevention representing the largest single category.
        COPQ over 20% of total COQ signals a quality system that is reactive, not proactive.
      </div>
    </div>
  </>);
}


// ─────────────────────────────────────────────
// MODULE 26 — Quality Culture Assessment
// ─────────────────────────────────────────────
export function Module26_QualityCulture() {
  const [scores, setScores] = useState({});
  const dims = [
    { key:"leadership", label:"Leadership Commitment", q:"Does top management visibly champion quality — not just production output?" },
    { key:"accountability", label:"Accountability", q:"Do individuals own quality outcomes for their area, or is quality 'the QM's job'?" },
    { key:"communication", label:"Quality Communication", q:"Is quality data visible, discussed, and acted on at all levels?" },
    { key:"prevention", label:"Prevention Mindset", q:"Does the team proactively prevent problems or primarily react to them?" },
    { key:"learning", label:"Learning from Failure", q:"Are failures analyzed and learned from, or just fixed and forgotten?" },
    { key:"pride", label:"Pride in Workmanship", q:"Do operators take personal pride in producing quality parts?" },
  ];
  const avg = dims.length>0&&Object.keys(scores).length>0 ? (Object.values(scores).reduce((a,b)=>a+b,0)/Object.keys(scores).length).toFixed(1) : "—";
  const maturity = !scores||Object.keys(scores).length<dims.length?"Incomplete":avg>=4?"World Class":avg>=3?"Progressing":avg>=2?"Developing":"Reactive";
  const maturityColor = maturity==="World Class"?"#34d399":maturity==="Progressing"?"#3b82f6":maturity==="Developing"?"#f59e0b":"#ef4444";
  return wrap(<>
    <div style={{marginBottom:20}}>
      <span style={S.badge("#8b5cf6")}>MODULE 26</span>
      <h1 style={{...S.h1,marginTop:8}}>Quality Culture Self-Assessment</h1>
      <p style={{color:"#64748b",fontSize:13,margin:"4px 0 0"}}>Rate your organization on each dimension (1=Poor, 5=Excellent)</p>
    </div>
    <div style={S.card}>
      {dims.map((d,i)=>(
        <div key={i} style={{marginBottom:18,paddingBottom:18,borderBottom:i<dims.length-1?"1px solid #1e293b":"none"}}>
          <div style={{fontWeight:700,color:"#f1f5f9",fontSize:13,marginBottom:4}}>{d.label}</div>
          <div style={{fontSize:12,color:"#64748b",marginBottom:8,lineHeight:1.5}}>{d.q}</div>
          <div style={{display:"flex",gap:6}}>
            {[1,2,3,4,5].map(v=>(
              <button key={v} onClick={()=>setScores({...scores,[d.key]:v})}
                style={{flex:1,padding:"8px 0",background:scores[d.key]===v?["#ef4444","#f97316","#f59e0b","#3b82f6","#34d399"][v-1]+"30":"#0f172a",border:`1px solid ${scores[d.key]===v?["#ef4444","#f97316","#f59e0b","#3b82f6","#34d399"][v-1]:"#334155"}`,borderRadius:6,color:scores[d.key]===v?["#ef4444","#f97316","#f59e0b","#3b82f6","#34d399"][v-1]:"#475569",fontWeight:700,fontSize:14,cursor:"pointer",fontFamily:"inherit",transition:"all 0.15s"}}>
                {v}
              </button>
            ))}
          </div>
          {scores[d.key]&&<div style={{fontSize:11,color:"#475569",marginTop:4}}>Rated: {["","Reactive — major gap","Below average","Developing","Good","World Class"][scores[d.key]]}</div>}
        </div>
      ))}
    </div>
    {Object.keys(scores).length===dims.length&&(
      <div style={{...S.card,border:`1px solid ${maturityColor}50`,textAlign:"center"}}>
        <div style={{fontSize:11,color:"#64748b",marginBottom:4,letterSpacing:1}}>CULTURE MATURITY SCORE</div>
        <div style={{fontSize:52,fontWeight:800,color:maturityColor}}>{avg}</div>
        <div style={{fontSize:20,fontWeight:700,color:maturityColor,marginBottom:12}}>{maturity}</div>
        <div style={{fontSize:13,color:"#94a3b8",lineHeight:1.6,textAlign:"left",padding:"0 8px"}}>
          {maturity==="World Class"&&"Outstanding — quality is embedded in the culture. Focus on sustaining and benchmarking against industry leaders."}
          {maturity==="Progressing"&&"Good foundation. Identify the 2-3 lowest-scoring dimensions and build targeted improvement plans."}
          {maturity==="Developing"&&"Quality culture is building but gaps remain. Leadership visibility and accountability systems need strengthening."}
          {maturity==="Reactive"&&"Quality is treated as inspection-only. Major culture change initiative required starting with leadership commitment."}
        </div>
      </div>
    )}
  </>);
}


// ─────────────────────────────────────────────
// MASTER EXPORT — All visuals indexed by module
// ─────────────────────────────────────────────
export const ALL_MODULE_VISUALS = {
  1:  Module01_QualityTimeline,
  2:  Module02_QMSHierarchy,
  3:  Module03_ISO9001Clauses,
  4:  Module04_AS9100Delta,
  5:  Module05_DefenseFlowDown,
  7:  Module07_GDT,
  8:  Module08_Metrology,
  11: Module11_Statistics,
  12: Module12_SPC,
  13: Module13_GaugeRR,
  14: Module14_Fishbone,
  16: Module16_FAIR,
  20: Module20_SupplierScorecard,
  21: Module21_FMEA,
  24: Module24_COQ,
  26: Module26_QualityCulture,
};

// Default export — visual browser for testing all components
export default function AllVisualsDemo() {
  const [active, setActive] = useState(1);
  const Component = ALL_MODULE_VISUALS[active];
  const modules = Object.keys(ALL_MODULE_VISUALS).map(Number);
  return (
    <div style={{fontFamily:"'DM Sans','Segoe UI',sans-serif",background:"#0a0f1e",minHeight:"100vh"}}>
      <div style={{background:"#0f172a",borderBottom:"1px solid #1e293b",padding:"12px 24px",display:"flex",gap:8,flexWrap:"wrap",alignItems:"center"}}>
        <span style={{fontSize:12,color:"#475569",marginRight:8,fontWeight:700}}>MODULE:</span>
        {modules.map(m=>(
          <button key={m} onClick={()=>setActive(m)}
            style={{background:active===m?"#1d4ed8":"#1e293b",border:`1px solid ${active===m?"#3b82f6":"#334155"}`,borderRadius:6,padding:"4px 10px",color:active===m?"#93c5fd":"#64748b",fontSize:12,cursor:"pointer",fontFamily:"inherit",fontWeight:active===m?700:400}}>
            {m}
          </button>
        ))}
      </div>
      {Component && <Component />}
    </div>
  );
}
