-- Run this in the Supabase SQL Editor (Dashboard > SQL Editor > New Query)

-- Employees table
CREATE TABLE IF NOT EXISTS employees (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Progress table
CREATE TABLE IF NOT EXISTS progress (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  employee_name TEXT NOT NULL REFERENCES employees(name) ON DELETE CASCADE,
  module_id INTEGER NOT NULL,
  module_title TEXT NOT NULL,
  lesson_completed BOOLEAN DEFAULT false,
  quiz_score INTEGER,
  quiz_passed BOOLEAN DEFAULT false,
  completed_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(employee_name, module_id)
);

-- Index for fast lookups
CREATE INDEX IF NOT EXISTS idx_progress_employee ON progress(employee_name);

-- Enable Row Level Security
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE progress ENABLE ROW LEVEL SECURITY;

-- Allow anonymous access (app uses anon key)
CREATE POLICY "Allow all access to employees" ON employees FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to progress" ON progress FOR ALL USING (true) WITH CHECK (true);
